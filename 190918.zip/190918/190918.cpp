#include <iostream>
#include <Windows.h>
#include "Blocks.h"

using namespace std;

void gotoxy(int x, int y);
void printsquare(int p[2]);
void clearpoint(int p[2]);

void color(int x);

void printblock(Block &block);

int main(){
	Block block1(0, 0, 1);

	block1.ChangePosition(4, 4);
	color(10);

	for (int i = 0; i < 20; i++){
		printblock(block1);
		Sleep(200);
		
		block1.RotateBlock(1);
	}

	gotoxy(20, 20);

	return 0;
}

void gotoxy(int x, int y){
	COORD coord = { 2*x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void printsquare(int p[2]){
	gotoxy(p[0], p[1]);
	cout << (char)0xa1 << (char)0xe1;
}

void clearpoint(int p[2]){
	gotoxy(p[0], p[1]);
	cout << ' ';
}

void color(int x){
	/*
	0 - black
	1 - blue
	2 - green
	3 - cyan
	4 - red
	5 - magenta
	6 - yellow
	7 - white
	8 - gray
	9~15 - light
	*/
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), x);
}

void printblock(Block &block){
	int p1[2];
	int p2[2];
	int p3[2];
	int p4[2];

	block.GetSequence(p1, p2, p3, p4);

	system("cls");
	printsquare(p1);
	printsquare(p2);
	printsquare(p3);
	printsquare(p4);
}