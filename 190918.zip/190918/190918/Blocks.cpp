#include "Blocks.h"

int Seq[5][4][2] = {
	{ { 0, 0 }, { 1, 0 }, { 2, 0 }, { 3, 0 } },//Iseq
	{ { 0, 0 }, { 1, 0 }, { 1, 1 }, { 1, 2 } },//Lseq
	{ { 0, 0 }, { 1, 0 }, { 2, 0 }, { 1, 1 } },//Tseq
	{ { 0, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 } },//Oseq
	{ { 0, 0 }, { 1, 0 }, { 1, 1 }, { 2, 1 } }//Sseq
};

Block::Block(int blocktype){
	b_type = blocktype;
	for (int i = 0; i < 4; i++){
		for (int j = 0; j < 2; j++){
			seq[i][j] = Seq[b_type][i][j];
		}
	}
	pivot[0] = 0, pivot[1] = 0;
} 

Block::~Block(){
	return;
}

void Block::RotateBlock(int dir){
	for (int i = 0; i < 4; i++){
		int x, int y;
		x = seq[i][0];
		y = seq[i][1];

		seq[i][0] = y * dir;
		seq[i][1] = -x * dir;
	}
}
void Block::ChangePosition(int x, int y){
	pivot[0] = x;
	pivot[1] = y;
}
void Block::GetSequence(int p1[2], int p2[2], int p3[2], int p4[2]){
	p1 = seq[0];
	p2 = seq[1];
	p3 = seq[2];
	p4 = seq[3];
}

int Block::GetBlockType(){
	return b_type;
}
