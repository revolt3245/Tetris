#include <iostream>
#include <Windows.h>

using namespace std;

void gotoxy(int x, int y);
void color(int x);

int main(){
	return 0;
}

void gotoxy(int x, int y){
	COORD coord = { 2*x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void color(int x){
	/*
	0 - black
	1 - blue
	2 - green
	3 - cyan
	4 - red
	5 - magenta
	6 - yellow
	7 - white
	8 - gray
	9~15 - light
	*/
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), x);
}