#pragma once

class Block{
private:
	int seq[4][2];
	int pivot[2];
	int b_type;
public:
	Block(int blocktype);
	void RotateBlock(int dir);
	void ChangePosition(int x, int y);
	void GetSequence(int p1[2], int p2[2], int p3[2], int p4[2]);
	int GetBlockType();
	~Block();
};