#include "Blocks.h"

int Seq[7][4][2] = {
	{ { 0, 0 }, { 1, 0 }, { 2, 0 }, { 3, 0 } },//Iseq
	{ { 0, 0 }, { 1, 0 }, { 1, 1 }, { 1, 2 } },//Lseq1
	{ { 0, 0 }, { 1, 0 }, { 2, 0 }, { 2, 1 } },//Lseq2
	{ { 0, 0 }, { 1, 0 }, { 2, 0 }, { 1, 1 } },//Tseq
	{ { 0, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 } },//Oseq
	{ { 0, 0 }, { 1, 0 }, { 1, 1 }, { 2, 1 } },//Sseq1
	{ { 0, 1 }, { 1, 1 }, { 1, 0 }, { 2, 0 } }//Sseq2
};

Block::Block(int blocktype, int rotate, int dir){
	b_type = blocktype;
	for (int i = 0; i < 4; i++){
		for (int j = 0; j < 2; j++){
			seq[i][j] = Seq[b_type][i][j];
		}
	}
	pivot[0] = 0, pivot[1] = 0;

	for (int i = 0; i < rotate; i++){
		this->RotateBlock(dir);
	}
} 

Block::~Block(){
	return;
}

void Block::RotateBlock(int dir){
	for (int i = 0; i < 4; i++){
		int x, y;
		x = seq[i][0];
		y = seq[i][1];

		seq[i][0] = y * dir;
		seq[i][1] = -x * dir;
	}
}
void Block::ChangePosition(int x, int y){
	pivot[0] = x;
	pivot[1] = y;
}
void Block::GetSequence(int p1[2], int p2[2], int p3[2], int p4[2]){
	for (int i = 0; i < 2; i++){
		p1[i] = seq[0][i] + pivot[i];
		p2[i] = seq[1][i] + pivot[i];
		p3[i] = seq[2][i] + pivot[i];
		p4[i] = seq[3][i] + pivot[i];
	}
	
}

int Block::GetBlockType(){
	return b_type;
}
